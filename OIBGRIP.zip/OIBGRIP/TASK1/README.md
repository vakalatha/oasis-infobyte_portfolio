## <center>Task 1 <br> Landing Page</center>


- [Click Here to visit site](http://diplomagraduate.ezyro.com/task1/?i=1)

<hr>

```
* Screenshots of task
```
<br>
<center>
<img src="images/task.png" width="70%" height="auto" />
<br><br>
<img src="images/task_1.png" width="70%" height="auto" />
<br><br>
<img src="images/task_1_1.png" width="70%" height="auto" />
</center>