## <center>Task 3 <br> Temperature Converter</center>


- [Click Here to visit site](http://diplomagraduate.ezyro.com/task3/?i=1)

<hr>

```
* Screenshots of task
```
<br>
<center>
<img src="images/task.png" width="70%" height="auto" />
<br><br>
<img src="images/task1.png" width="70%" height="auto" />
<br><br>
</center>