
# <center>This repository is created for OASIS INTERNSHIP TASKS</center>


### I have complete 3 tasks from level 1 in Web development domain:

- [Task 1 - Landing Page](http://diplomagraduate.ezyro.com/task1/?i=1)
- [Task 2 - Portfolio Website](http://diplomagraduate.ezyro.com/task2/?i=1)
- [Task 3 - Temperature Converter](http://diplomagraduate.ezyro.com/task3/?i=1)

``` 
- If links are dead please let me know!
```

<hr>

### Offer Letter from OASIS INFOBYTE

<br/>

<center>
<img src="media/INTERNSHIP_OFFER_LETTER.jpg" data-canonical-src="https://gyazo.com/eb5c5741b6a9a16c692170a41a49c858.png" width="70%" height="auto" />
</center>

<br>
<br>

# Where you can apply for this internship ?

- [Click here to apply](https://www.oasisinfobyte.in/)